from ..engine import run_game
from ..games import even


def main():
    run_game(even)

if __name__ == "__main__":
    main()