### Hexlet tests and linter status:
[![Actions Status](https://github.com/milcford/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/milcford/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/0a2bd6caa026b60df07d/maintainability)](https://codeclimate.com/github/milcford/python-project-49/maintainability)

brain-even: https://asciinema.org/a/Vsl6y1ThigQDXAnP7ypjapm2E
brain-calc: https://asciinema.org/a/biP9CsrpZMpmyCX8sewMWj31R
brain-progression: https://asciinema.org/a/Yf6FLhHLzau9LZCCQ4DAp4chr